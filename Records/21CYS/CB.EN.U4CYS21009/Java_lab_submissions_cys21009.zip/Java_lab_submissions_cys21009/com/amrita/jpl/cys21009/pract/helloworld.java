package com.amrita.jpl.cys21009.pract;

/**
 * Program which prints "Hello world!"
 * @author Aravind
 * @version 1
 */
public class helloworld {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}